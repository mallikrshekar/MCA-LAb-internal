#include<lpc213x.h>

unsigned int val;
	
void delay(unsigned int val)	
{
	for(val=1;val<=60000;val++);
}

int main()
{
    PINSEL0=0x00000000;
    PINSEL1=0x00000000;
    PINSEL2=0x00000000;
		IO0DIR|=0xffffffff;
	
	while(1)
	{ 
			unsigned  long int j;
			int i,array[]={0x3f,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
		 
		 
		for(j=0;j<10;j++)	
		{ 
			IO0SET=IO0SET|array[j];
			for(i=0;i<10;i++)
			{
					IO0SET= IO0SET|(array[i]<<8);
					delay(100000);
					IO0CLR= IO0CLR|(array[i]<<8);
			}
			IO0CLR=array[j];
		}
	}
}
